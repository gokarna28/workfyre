<?php
// PHP template for Page 4 - Legacy to Live By - Page 4
echo "<h1>Legacy to Live By - Page 4</h1>";
echo "<div id='video-placeholder'>[VIDEO PLACEHOLDER]</div>";
echo "<div class='content'><p>Full content for Page 4 of Legacy to Live By goes here.</p></div>";
?>