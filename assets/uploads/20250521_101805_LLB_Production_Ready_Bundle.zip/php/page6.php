<?php
// PHP template for Page 6 of Legacy to Live By
echo 'Page 6 content will be dynamically loaded here.';
?>