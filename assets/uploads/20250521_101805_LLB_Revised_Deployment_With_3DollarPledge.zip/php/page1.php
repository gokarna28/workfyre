<?php
// PHP template for Page 1 - Welcome to Legacy to Live By
echo "<h1>Welcome to Legacy to Live By</h1>";
echo "<div id='video-placeholder'>[VIDEO PLACEHOLDER]</div>";
echo "<div class='content'><p>Full content for Page 1 of Legacy to Live By goes here.</p><p>💥 Your $3 pledge unlocks a 10-pack of YAM vouchers—delivering $100 in rebates, social impact, and rewards.</p></div>";
?>