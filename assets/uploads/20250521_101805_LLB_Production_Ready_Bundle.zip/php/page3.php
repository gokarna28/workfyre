<?php
// PHP template for Page 3 of Legacy to Live By
echo 'Page 3 content will be dynamically loaded here.';
?>