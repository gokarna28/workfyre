
document.addEventListener('DOMContentLoaded', function() {
  console.log("Legacy to Live By script loaded.");
});
