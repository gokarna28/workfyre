<?php
// PHP template for Page 2 - What Is the Cookie Jar Economy?
echo "<h1>What Is the Cookie Jar Economy?</h1>";
echo "<div id='video-placeholder'>[VIDEO PLACEHOLDER]</div>";
echo "<div class='content'><p>Full content for Page 2 of Legacy to Live By goes here.</p><p>💡 One $3 pledge funds a 10-pack of YAM vouchers—delivering $5 rebates, $4 social impact, and a full $100 in tracked community value.</p></div>";
?>