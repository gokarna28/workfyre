<?php
// PHP template for Page 11 of Legacy to Live By
echo 'Page 11 content will be dynamically loaded here.';
?>