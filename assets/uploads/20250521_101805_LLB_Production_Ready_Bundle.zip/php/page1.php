<?php
// PHP template for Page 1 of Legacy to Live By
echo 'Page 1 content will be dynamically loaded here.';
?>